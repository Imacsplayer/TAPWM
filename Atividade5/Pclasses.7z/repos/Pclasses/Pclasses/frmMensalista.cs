﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstanciar1_Click(object sender, EventArgs e)
        {
            Mensalista mensalista = new Mensalista();

            mensalista.NomeEmpregado = txtNome.Text;
            mensalista.Matricula = Convert.ToInt32(txtMatricula.Text);
            mensalista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            mensalista.SalarioMensal = Convert.ToDouble(txtSalario.Text);

            MessageBox.Show("Nome = " + mensalista.NomeEmpregado + "\n" +
                "Matrícula = " + mensalista.Matricula + "\n" +
                "Tempo Trabalho = " + mensalista.TempoTrabalho() +
                "\n" + "Salário Final = " + mensalista.SalarioBruto().ToString("N2"));

            //static
            MessageBox.Show(Mensalista.Empresa);
            MessageBox.Show(Mensalista.Filial);
        }

        private void btnInstanciar2_Click(object sender, EventArgs e)
        {
            Mensalista mensalista2 = new Mensalista();

            //MessageBox.Show("Nome = " + mensalista2.NomeEmpregado + "\n" +
            //    "Matrícula = " + mensalista2.Matricula + "\n" +
            //    "Tempo Trabalho = " + mensalista2.TempoTrabalho() +
            //    "\n" + "Salário Final = " + mensalista2.SalarioBruto().ToString("N2"));

        }
    }
}
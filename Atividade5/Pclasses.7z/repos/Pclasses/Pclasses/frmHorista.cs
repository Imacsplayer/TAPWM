﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Horista horista = new Horista();

            horista.NomeEmpregado = txtNome.Text;
            horista.Matricula = Convert.ToInt32(txtMatricula.Text);
            horista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            horista.NumeroHora = Convert.ToDouble(txtHora.Text);
            horista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            horista.DiasFalta = Convert.ToInt32(txtFalta.Text);

            MessageBox.Show("Nome = " + horista.NomeEmpregado +
                "\n" + "Matrícula = " + horista.Matricula +
                "\n" + "Tempo de trabalho = " + horista.TempoTrabalho().ToString() +
                "\n" + "Salário = " + horista.SalarioBruto().ToString("N2"));

            MessageBox.Show($"Salário com aumento: {horista.SalarioBruto(50).ToString("N2")}");
        }
    }
}
